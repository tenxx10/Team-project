/**
 * 
 */

// 연제구 보건소

var HOME_PATH = window.HOME_PATH || '.';

var map = new naver.maps.Map(document.getElementById('map'), {
    center: new naver.maps.LatLng(35.1794, 129.0762), // 
    zoom: 13
});

/*

var map = new naver.maps.Map(document.getElementById('map'), {
    zoom: 16,
    center: yeonjeLocation // 연제구 보건소 위치로 이동
});


// 부산 연제구 보건소 마커 생성
var yeonjeHealthCenterMarker = new naver.maps.Marker({
    map: map,
    position: yeonjeLocation
});

*/

// 부산 연제구 보건소에 대한 정보
var yeonjeHealthCenterContentString = [
    '<div class="iw_inner">',
    '   <h3>연제구 보건소</h3>',
    '   <p>부산 연제구 ~~~ | 부산 연제구 ~~~<br />',
    '       <img src="'+ HOME_PATH +'/img/example/yeonje_health_center.jpg" width="55" height="55" alt="연제구 보건소" class="thumb" /><br />',
    '       전화번호: 051-xxx-xxxx<br />',
    '       주소: 부산 연제구 ~~~<br />',
    '       <a href="http://www.yeonje.go.kr" target="_blank">www.yeonje.go.kr/</a>',
    '   </p>',
    '</div>'
].join('');

// 부산 연제구 보건소 정보 창 생성
var yeonjeHealthCenterInfowindow = new naver.maps.InfoWindow({
    content: yeonjeHealthCenterContentString,
    maxWidth: 140,
    backgroundColor: "#eee",
    borderColor: "#2db400",
    borderWidth: 5,
    anchorSize: new naver.maps.Size(30, 30),
    anchorSkew: true,
    anchorColor: "#eee",
    pixelOffset: new naver.maps.Point(20, -20)
});

// 부산 연제구 보건소 마커 클릭 이벤트
naver.maps.Event.addListener(yeonjeHealthCenterMarker, "click", function(e) {
    if (yeonjeHealthCenterInfowindow.getMap()) {
        yeonjeHealthCenterInfowindow.close();
    } else {
        yeonjeHealthCenterInfowindow.open(map, yeonjeHealthCenterMarker);
    }
});


var latlngs = [
  new naver.maps.LatLng(35.1795543, 129.0756416),
  new naver.maps.LatLng(35.1580273, 128.9865896),
  new naver.maps.LatLng(35.3359792, 129.1779167),
  new naver.maps.LatLng(35.1462124, 129.0598705),
  new naver.maps.LatLng(35.2113842, 129.0798625),
  new naver.maps.LatLng(35.2392384, 129.0147818),
  new naver.maps.LatLng(35.0943098, 128.9594344),
  new naver.maps.LatLng(35.1360966, 129.0849714),
  new naver.maps.LatLng(35.1641139, 129.1786601),
  new naver.maps.LatLng(35.1768327, 129.0791413),
  new naver.maps.LatLng(35.2296889, 129.1475501)
];

var markerList = [];

for (var i = 0, ii = latlngs.length; i < ii; i++) {
  var seq = i * 29;
  var icon = {
    url: HOME_PATH + '.',
    size: new naver.maps.Size(24, 37),
    anchor: new naver.maps.Point(12, 37),
    origin: new naver.maps.Point(seq, 0)
  };

  var marker = createMarker(latlngs[i], icon, i);
  markerList.push(marker);
}

function createMarker(position, icon, seq) {
  var marker = new naver.maps.Marker({
    position: position,
    map: map,
    icon: icon
  });

  marker.set('seq', seq);

  marker.addListener('mouseover', onMouseOver);
  marker.addListener('mouseout', onMouseOut);
  marker.addListener('click', onMarkerClick);

  return marker;
}

function onMouseOver(e) {
  var marker = e.overlay,
    seq = marker.get('seq');

  updateMarkerIcon(marker, seq, true);
}

function onMouseOut(e) {
  var marker = e.overlay,
    seq = marker.get('seq');

  updateMarkerIcon(marker, seq, false);
}

function updateMarkerIcon(marker, seq, isMouseOver) {
  var prefix = isMouseOver ? '_over' : '';
  marker.setIcon({
    url: HOME_PATH + '/img/example/sp_pins_spot_v3' + prefix + '.png',
    size: new naver.maps.Size(24, 37),
    anchor: new naver.maps.Point(12, 37),
    origin: new naver.maps.Point(seq, isMouseOver ? 50 : 0)
  });
}

function onMarkerClick(e) {
  var marker = e.overlay;
  var infowindowContent = 'Information about Busan Health Center'; // Replace with actual content
  openInfowindow(marker.getPosition(), infowindowContent);
}

function openInfowindow(position, content) {
  var infowindow = new naver.maps.InfoWindow({
    content: content
  });

  infowindow.open(map, position);
}





// 보건소 위치
var busanLocation = new naver.maps.LatLng(35.1795543, 129.0756416); // 부산동부지부(동래)의 좌표
var westLocation = new naver.maps.LatLng(35.1580273, 128.9865896); //서부지부 좌표
var gijangLocation = new naver.maps.LatLng(35.3359792, 129.1779167); //기장군보건소 정관지소 좌표
var jinguLocation = new naver.maps.LatLng(35.1462124, 129.0598705); //부산진구보건소보건소 좌표
var dongraeLocation = new naver.maps.LatLng(35.2113842, 129.0798625); //동래구보건소 좌표
var bukguLocation = new naver.maps.LatLng(35.2392384, 129.0147818); //부산북구보건소 좌표
var sahaLocation = new naver.maps.LatLng(35.0943098, 128.9594344); //사하구보건소 좌표
var namLocation = new naver.maps.LatLng(35.1360966, 129.0849714); //남구보건소 좌표
var haeundaeLocation = new naver.maps.LatLng(35.1641139, 129.1786601); //해운대구보건소 좌표
var yeonjeLocation = new naver.maps.LatLng(35.1768327, 129.0791413); //연제구보건소 좌표
var bansongLocation = new naver.maps.LatLng(35.2296889, 129.1475501); //반송보건지소 좌표

//각 보건소에 대한 마커 생성
var busanMarker = new naver.maps.Marker({
  position: busanLocation,
  map: map
});

var westMarker = new naver.maps.Marker({
  position: westLocation,
  map: map
});

var gijangMarker = new naver.maps.Marker({
  position: giyangLocation,
  map: map
});

var jinguMarker = new naver.maps.Marker({
  position: jinguLocation,
  map: map
});

var dongraeMarker = new naver.maps.Marker({
  position: dongraeLocation,
  map: map
});

var sahaMarker = new naver.maps.Marker({
  position: sahaLocation,
  map: map
});

var namMarker = new naver.maps.Marker({
  position: namLocation,
  map: map
});

var haeundaeMarker = new naver.maps.Marker({
  position: haeundaeLocation,
  map: map
});

var yeonjeMarker = new naver.maps.Marker({
  position:  yeonjeLocation,
  map: map
});

var bansongMarker = new naver.maps.Marker({
  position: bansongLocation,
  map: map
});



// 각 보건소에 대한 정보창 생성
var busanInfowindow = new naver.maps.InfoWindow({
  content: 'Information about Busan Health Center'
});


// 보건소
naver.maps.Event.addListener(busanMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, busanMarker);
});

naver.maps.Event.addListener(westMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, westMarker);
});

naver.maps.Event.addListener(gijangMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, gijangMarker);
});

naver.maps.Event.addListener(jinguMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, jinguMarker);
});

naver.maps.Event.addListener(dongraeMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, dongraeMarker);
});

naver.maps.Event.addListener(sahaMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, sahaMarker);
});

naver.maps.Event.addListener(namMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, namMarker);
});

naver.maps.Event.addListener(haeundaeMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, haeundaeMarker);
});

naver.maps.Event.addListener(yeonjeMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, yeonjeMarker);
});

naver.maps.Event.addListener(bansongMarker, "click", function(e) {
  toggleInfowindow(busanInfowindow, bansongMarker);
});

// 정보창 열고 닫는 함수
function toggleInfowindow(infowindow, marker) {
  if (infowindow.getMap()) {
    infowindow.close();
  } else {
    infowindow.open(map, marker);
  }
}


// 마커 클릭 이벤트 리스너 등록
naver.maps.Event.addListener(busanMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, busanMarker);
  }
});

naver.maps.Event.addListener(westMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, westMarker);
  }
});

naver.maps.Event.addListener(gijangMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, gijangMarker);
  }
});

naver.maps.Event.addListener(jinguMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, jinguMarker);
  }
});

naver.maps.Event.addListener(dongraeMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, dongraeMarker);
  }
});

naver.maps.Event.addListener(sahaMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, sahaMarker);
  }
});

naver.maps.Event.addListener(namMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, namMarker);
  }
});

naver.maps.Event.addListener(haeundaeMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, haeundaeMarker);
  }
});

naver.maps.Event.addListener(yeonjeMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, yeonjeMarker);
  }
});

naver.maps.Event.addListener(bansongMarker, "click", function(e) {
  if (busanInfowindow.getMap()) {
    busanInfowindow.close();
  } else {
    busanInfowindow.open(map, bansongMarker);
  }
});




	
/*

// KML 데이터 레이어 적용하기

//지도 초기화
var map = new naver.maps.Map(document.getElementById('map'), {
    zoom: 12,
    mapTypeId: 'normal',
    center: new naver.maps.LatLng(38.1361378, 128.4021238)
});


// KML 데이터 '/data/seorak.kml' 로드 -> 보건소 xml
var HOME_PATH = window.HOME_PATH || '.';
var serviceKey = '57SI3KVH-57SI-57SI-57SI-57SI3KVHCK'; // 서비스키 값은 실제 서비스키로 변경

// URL 생성
var urlBuilder = HOME_PATH + '/data/nationwide_health_centers.xml';  // 예시임
urlBuilder += '?serviceKey=' + encodeURIComponent(serviceKey); //Service Key

// fetch를 사용하여 XML 데이터 요청
fetch(urlBuilder)
    .then(response => response.text())
    .then(xmlString => {
        // 문자열을 XML 문서로 파싱
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(xmlString, 'application/xml');

        // KML 데이터 추가 (map.data.addKml을 통해 데이터 레이어에 추가)
        startDataLayer(xmlDoc);
    })
    .catch(error => console.error('Error:', error));

// KML 데이터 추가 (map.data.addKml을 통해 데이터 레이어에 추가)
function startDataLayer(xmlDoc) {
    map.data.addKml(xmlDoc);
}


*/
	
	
	
	
	
	
	
	
	
	