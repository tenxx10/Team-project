document.addEventListener('DOMContentLoaded', function () {
            $(function () {
                var request = $.ajax({
                    url: "/full-calendar/calendar-admin", // 변경하기
                    method: "GET",
                    dataType: "json"
                });
 
                request.done(function (data) {
                    console.log(data); // log 로 데이터 찍어주기.
 
                    var calendarEl = document.getElementById('calendar');
 
                    var calendar = new FullCalendar.Calendar(calendarEl, {
                        initialDate: '2022-02-07',
                        initialView: 'timeGridWeek',
                        headerToolbar: {
                            left: 'prev,next today',
                            center: 'title',
                            right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
                        },
                        editable: true,
                        droppable: true, // this allows things to be dropped onto the calendar
                        drop: function (arg) {
                            // is the "remove after drop" checkbox checked?
                            if (document.getElementById('drop-remove').checked) {
                                // if so, remove the element from the "Draggable Events" list
                                arg.draggedEl.parentNode.removeChild(arg.draggedEl);
                            }
                        },
                        /**
                         * data 로 값이 넘어온다. log 값 전달.
                         */
                        events: data
                    });
 
                    calendar.render();
                });
 
                request.fail(function( jqXHR, textStatus ) {
                    alert( "Request failed: " + textStatus );
                });
            });
 
        });

        // 여기서부터 삭제하기 
        var calendar =null;			

    document.addEventListener('DOMContentLoaded', function() {
        var Calendar = FullCalendar.Calendar;
        var Draggable = FullCalendar.Draggable;

        var containerEl = document.getElementById('external-events');
        var calendarEl = document.getElementById('calendar');
        var checkbox = document.getElementById('drop-remove');

        //***개발문서 주소 https://fullcalendar.io/docs ***

        // 미리 생성된 외부 이벤트, 요금유형(external events) 초기화(드래그 드롭이 가능한 이벤트)
        // -----------------------------------------------------------------
        
        //전체 이벤트 초기화
        var all_events = null;


        //DB에 있는 모든 이벤트를 가져오는 함수 getPlan() 실행
        all_events = getPlan();

        // console.log(all_events);
            
        //드래그가 가능한 이벤트(드래그를 해서 날짜에 이벤트 요소를 전달할 수 있는 외부 이벤트를 의미, extendedProps는 이벤트 요소의 dataset값으로 이벤트의 정보를 전달하는 fullcalendar에서 정의되지 않은 필드(NON-standard Fields)를 생성할 수 있음)
        new Draggable(containerEl, {
            itemSelector: '.fc-event',
            eventData: function(eventEl) {
                var dataset = eventEl.dataset;

                return {
                    title: eventEl.innerText,
                    extendedProps: {
                        chargetypeno: dataset.chargetypeno,
                        typecolor: dataset.typecolor,
                    },
                
                };
                
            }
            
        });


        // 달력 초기화
        // -----------------------------------------------------------------
        
        calendar = new Calendar(calendarEl, {
            headerToolbar: {
                left: '',
                center: 'title',
                right: 'prev,next today',
            },
            initialView: 'dayGridMonth', //달력 종류
            locale: 'ko', //달력 호환 언어설정
            events: all_events, //위에서 getPlan()로 전달된 이벤트 data를 담은 배열
            editable: false, //달력 안에서 생성된 이벤트의 수정이 가능한지 여부
            droppable: true, // this allows things to be dropped onto the calendar
            drop: function(info) {
                // is the "remove after drop" checkbox checked?
                if (checkbox.checked) {
                // if so, remove the element from the "Draggable Events" list
                info.draggedEl.parentNode.removeChild(info.draggedEl);
                }
                
            },
            //eventContent는 이벤트의 요소를 생성하는 함수
            eventContent: function (info) {
                let italicEl = document.createElement('div')
                            
                italicEl.innerHTML = '<div class="calender-droped-event" data-chargetypeno="'+info.event.extendedProps.chargetypeno+'" data-typecolor="'+info.event.extendedProps.typecolor+'">'+info.event.title+'</div>';

                let arrayOfDomNodes = [italicEl]
                return { domNodes: arrayOfDomNodes }
            },
            //*** 이벤트를 클릭했을 때 클릭한 이벤트를 컨트롤할 수 있는 실행되는 콜백함수 ***
            eventClick: function(arg) {
                if (confirm('선택하신 요금유형을 삭제하시겠습니까?')) {
                arg.event.remove();  //이벤트 삭제함수
                }
            },
            //*** 달력에 이벤트를 추가했을 때마다 추가한 이벤트를 컨트롤할 수 있는 콜백함수***
            eventReceive: function( info ) { 
                //console.log(info.event);

                var newEnvet = info.event;

                var events = new Array();
                var obj = new Object();

                obj.chargetypeno = newEnvet._def.extendedProps.chargetypeno;
                obj.start = newEnvet._instance.range.start; //요금 시작일
                events.push(obj);


                var jsondata = JSON.stringify(events);
                //console.log(jsondata);
                
                //이벤트 data를 update하는 함수를 비동기로 AJAX호출하는 함수 실행
                updatedata(jsondata);

                calendar.refetchEvents();

            },
            //*** 달력에 이벤트를 삭제했을 때마다 삭제한 이벤트를 컨트롤할 수 있는 콜백함수 ***
            eventRemove: function( removeInfo ) { 
                //console.log(removeInfo.event);

                var deleteEnvet = removeInfo.event;

                var events = new Array();

                

                var obj = new Object();

                obj.chargetypeno = deleteEnvet._def.extendedProps.chargetypeno;
                obj.start = deleteEnvet._instance.range.start; //요금 시작일
                events.push(obj);


                var jsondata = JSON.stringify(events);
                //console.log(jsondata);

                //이벤트 data를 dalete하는 함수를 비동기로 AJAX호출하는 함수 실행(*실제로 삭제하지는 않고 FK를 0으로 수정)
                deletedata(jsondata);
            }
                
        });

        //달력 렌더링
        calendar.render();

        // var alldata = null;
        // var alldata = calendar.getEvents();
        // console.log(alldata);

    });

//------AJAX함수 시작-------------------------------------------------------------------------------------------------------------------//

        //이벤트 data를 update하는 비동기로 AJAX호출하는 함수
        function updatedata(jsondata){
            $.ajax({
                type: 'POST',
                url: '/api/updateChargePlan',
                data: {"updatedata": jsondata},
                dataType: 'text',
                async: false
            })
            .done(function(result){
                //console.log(result);
                location.reload();
                alert("정상적으로 수정되었습니다");
            })
            .fail(function(request, status, error){
                alert("에러 발생" + error);
            })
        }

        //이벤트 data를 dalete하는 함수를 비동기로 AJAX호출하는 함수
        function deletedata(jsondata){
            $.ajax({
                type: 'POST',
                url: '/api/deleteChargePlan',
                data: {"deletedata": jsondata},
                dataType: 'text',
                async: true
            })
            .done(function(result){
                alert("정상적으로 삭제되었습니다");
                // location.reload();
            })
            .fail(function(request, status, error){
                alert("에러 발생" + error);
            })
        }

        //서버에 저장된 예약 데이터들을 가져오는 함수
        function getPlan(){

            var result_plan = null;

            $.ajax({
                type: 'POST',
                url: '/api/getPlan',
                data: {},
                dataType: 'json',

            })
            .done(function(result){
                result_plan = result;
            })
            .fail(function(request, status, error){
                alert("에러 발생" + error);
            })

            return result_plan;
        }