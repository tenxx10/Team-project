package calendar.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import calendar.model.CalModel;
import java.time.format.DateTimeFormatter;

public class CalController {
    private CalModel model;

    public CalController(CalModel model) {
        this.model = model;
    }

    public void updateChargePlan(String postData) {
        List<Map<String, Object>> dataArr = parseJson(postData);

        long start = getTimestamp(dataArr.get(0).get("start").toString());
        String date = formatDate(start);
        int chargetypeno = Integer.parseInt(dataArr.get(0).get("chargetypeno").toString());

        boolean result = model.updatePlan(date, chargetypeno);
    }

    public void deleteChargePlan(String postData) {
        List<Map<String, Object>> dataArr = parseJson(postData);

        long start = getTimestamp(dataArr.get(0).get("start").toString());
        String date = formatDate(start);
        int chargetypeno = Integer.parseInt(dataArr.get(0).get("chargetypeno").toString());

        boolean result = model.deletePlan(date, chargetypeno);
    }

    public List<Map<String, Object>> getPlan() {
        List<Map<String, Object>> result = model.getPlan();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        List<Map<String, Object>> processedResult = result.stream()
                .map(item -> Map.of(
                        "title", item.get("name"),
                        "allDay", true,
                        "start", item.get("date"),
                        "color", item.get("color"),
                        "typecolor", item.get("color"),
                        "chargetypeno", item.get("charge_type_no")
                ))
                .collect(Collectors.toList());

        System.out.println(processedResult); // Print JSON result

        return processedResult;
    }

    private List<Map<String, Object>> parseJson(String jsonData) {
        // Implement JSON parsing logic here
        // Return List of Maps representing the JSON data
        return null;
    }

    private long getTimestamp(String dateString) {
        // Implement logic to convert date string to timestamp
        // Return timestamp (in milliseconds)
        return 0;
    }

    private String formatDate(long timestamp) {
        // Implement logic to format timestamp to date string
        // Return formatted date string
        return null;
    }
}
