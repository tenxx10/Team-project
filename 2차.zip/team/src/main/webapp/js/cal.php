/*
php 
php 사이트에서 다운 후 -> help : install new software
php 있는 폴더 위치 설정 (* 여기서 환경설정 error생김
우선 캘린더의 정보를 저장할 db events 테이블 만들어야하고
CREATE TABLE events (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255),
    start DATETIME,
    end DATETIME
); + FK는  reserve테이블처럼 user_id와 동일하게 


*/


<?php
// 데이터베이스 연결 설정 (직접 설정)
$db_host = 'localhost';
$db_user = 'your_username';
$db_pass = 'your_password';
$db_name = 'your_database';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// FullCalendar에 전달할 이벤트 데이터 조회
$query = "SELECT id, title, start, end FROM events";
$result = $conn->query($query);

$events = array();

while ($row = $result->fetch_assoc()) {
    $events[] = $row;
}

$conn->close();

// JSON 형식으로 출력
echo json_encode($events);
?>
